from distutils.core import setup

setup(name='KJW',
      version='1.0',
      py_modules=['Gmail', 'Internet', 'Main', 'mysmtplib']
      )
