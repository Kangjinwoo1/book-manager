# -*- coding: utf-8 -*-
from Internet import *
from Gmail import*
##### global
loopFlag = 1

#### Menu  implementation
def printMenu():
    print("\n어서오세요! 생필품 가격 정보 조회 서비스 입니다 !\n (xml version)")
    print("========Menu==========")
    print(" 서버에 접속합니다                  :  t")
    print(" 상품명과 코드를 출력합니다          :  g")
    print(" 업체명와 코드를 출력합니다          :  e")
    print(" 상품별 상세정보 출력합니다          :  i")
    print(" 업체별 상품리스트 출력합니다        :  f")
    print(" 상품을 가격순으로 정렬합니다 (10개)   :  z")
    print(" 두 업체를 비교합니다               :  x")
    print(" 메일로 전송합니다                  :  s")
    print(" Quit program                      :  q")
    print("----------------------------------------")
    print("========Menu==========")
    
def launcherFunction(menu):
    if menu == 'q':
        QuitProgram()
    
    elif menu == 't':
        LoadXMLFromWeb()
        
    elif menu == 'i':
        GoodsSearch()
    
    elif menu == 'f':
        EntpSearch()
        
    elif menu == 'g':
        PrintGoods()
        
    elif menu == 'e':
        PrintEntp()
        
    elif menu == 'z':
        SortGood()
        
    elif menu == 'x':
        CompEntp()
        
    elif menu == 's':
        sendMail()        
        
    else:
        print ("error : 잘못된 키입력입니다 !")
        
def QuitProgram():
    global loopFlag
    loopFlag = 0
    
##### run #####
while(loopFlag > 0):
    printMenu()
    menuKey = str(input ("메뉴를 선택하세요 :"))
    launcherFunction(menuKey)
else:
    print ("Thank you! Good Bye")