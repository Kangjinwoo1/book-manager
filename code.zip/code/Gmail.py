from Internet import GoodsList
from Internet import EntpList
from Internet import checkDoc
host = "smtp.gmail.com" # Gmail STMP 서버 주소.
port = "587"

def MakeHtmlDoc():
    print("리스트를 받아옵니다")
    from xml.dom.minidom import getDOMImplementation
    # DOM 개체를 생성합니다.
    impl = getDOMImplementation()
    
    newdoc = impl.createDocument(None, "html", None)  # HTML 최상위 엘리먼트를 생성합니다.
    top_element = newdoc.documentElement
    header = newdoc.createElement('header')
    top_element.appendChild(header)

    # Body 엘리먼트 생성
    body = newdoc.createElement('body')

    for item in GoodsList:
        # Bold 엘리먼트를 생성합니다.
        b = newdoc.createElement('b')
        # 텍스트 노드를 만듭니다.
        ibsnText = newdoc.createTextNode("goodName:" + item)
        b.appendChild(ibsnText)

        body.appendChild(b)
    
        # <br> 부분을 생성합니다.
        br = newdoc.createElement('br')

        body.appendChild(br)

        # title 부분을 생성합니다.
        #p = newdoc.createElement('p')
        # 텍스트 노드를 만듭니다.
        #titleText= newdoc.createTextNode("Good:" + item[1])
        #p.appendChild(titleText)

        #body.appendChild(p)
        #body.appendChild(br)  # <br> 부분을 부모 에릴먼트에 추가합니다.
         
    # Body 엘리먼트를 최상위 엘리먼트에 추가시킵니다.
    top_element.appendChild(body)
    
    return newdoc.toxml()
    
def MakeHtmlDoc2():
    print("리스트를 받아옵니다")
    from xml.dom.minidom import getDOMImplementation
    # DOM 개체를 생성합니다.
    impl = getDOMImplementation()
    
    newdoc = impl.createDocument(None, "html", None)  # HTML 최상위 엘리먼트를 생성합니다.
    top_element = newdoc.documentElement
    header = newdoc.createElement('header')
    top_element.appendChild(header)

    # Body 엘리먼트 생성
    body = newdoc.createElement('body')

    for item in EntpList:
        # Bold 엘리먼트를 생성합니다.
        b = newdoc.createElement('b')
        # 텍스트 노드를 만듭니다.
        ibsnText = newdoc.createTextNode("entpName:" + item)
        b.appendChild(ibsnText)

        body.appendChild(b)
    
        # <br> 부분을 생성합니다.
        br = newdoc.createElement('br')

        body.appendChild(br)

        # title 부분을 생성합니다.
        #p = newdoc.createElement('p')
        # 텍스트 노드를 만듭니다.
        #titleText= newdoc.createTextNode("Good:" + item[1])
        #p.appendChild(titleText)

        #body.appendChild(p)
        #body.appendChild(br)  # <br> 부분을 부모 에릴먼트에 추가합니다.
         
    # Body 엘리먼트를 최상위 엘리먼트에 추가시킵니다.
    top_element.appendChild(body)
    
    return newdoc.toxml()

def sendMail():
    if not checkDoc():
        return None
        
    global host, port
    html = ""
    html2 = ""
    title = "생필품 가격 조회 서비스"
   
    senderAddr = "kjw955486@gmail.com" 
    recipientAddr = "kjw8576@naver.com" #str(input ('recipient email address :'))
    #msgtext = str(input ('write message :'))
    # passwd = "wlsdn9450"
    cmd = input("상품명을 전송하려면 a를, 업체명을 전송하려면 b를 누르세요 : ")
    
    if cmd == 'a':
        html = MakeHtmlDoc()
    else:
        html2 = MakeHtmlDoc2()
    
    import mysmtplib
    # MIMEMultipart의 MIME을 생성합니다.
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    
    #Message container를 생성합니다.
    msg = MIMEMultipart('alternative')

    #set message
    msg['Subject'] = title
    msg['From'] = senderAddr
    msg['To'] = recipientAddr
    
    
    
    #msgPart = MIMEText(msgtext, 'plain')
    if cmd == 'a':
        bookPart = MIMEText(html, 'html', _charset = 'UTF-8')
    else:
        bookPart2 = MIMEText(html2, 'html', _charset = 'UTF-8')
    
    # 메세지에 생성한 MIME 문서를 첨부합니다.
 
    #msg.attach(msgPart)
    if cmd == 'a':
        msg.attach(bookPart)
    else:
        msg.attach(bookPart2)
        
    print ("connect smtp server ... ")
    s = mysmtplib.MySMTP(host,port)
    #s.set_debuglevel(1)
    s.ehlo()
    s.starttls()
    s.ehlo()
    s.login("kjw955486@gmail.com", "wlsdn9450")  # 로긴을 합니다. 
    s.sendmail(senderAddr , [recipientAddr], msg.as_string())
    s.close()
    
    print ("Mail sending complete!!!")