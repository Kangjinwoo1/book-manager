# -*- coding: utf-8 -*-
from urllib.request import urlopen
from xml.dom.minidom import parse
from xml.etree import ElementTree

GoodsDoc = None
GoodsDic = dict()

EntpDoc = None
EntpDic = dict()

SortDic = dict()

GoodsList = []
EntpList = []

server = "openapi.price.go.kr"
key = "KKy%2BAYYltJMkYtLnGmAYqfMikLEDXF%2ByUSkEiLwr4k6VbsSyQShLOL2Vr4%2BzO9muBfz72h%2Blukq8LY5xmq7MAQ%3D%3D"

def checkDoc():
    global GoodsDoc, EntpDoc
    if GoodsDoc == None or EntpDoc == None :
        print("Error : Document is empty")
        return False
    return True
    
def EntpSearch():
    Doc = None
    url = None
    XML = None
    if not checkDoc():
        return None
    
    code = input("업체 코드를 입력하세요 : ")

    url = "http://"+server+"/openApiImpl/ProductPriceInfoService/getProductPriceInfoSvc.do?goodInspectDay=20160610&entpId="+code+"&ServiceKey="+key
    
    try:
        XML = urlopen(url)
        
    except IOError:
        print ("error : 서버접속에 실패했습니다 !")
        return False
        
    else:
        Doc = parse(XML)
           
    response = Doc.childNodes
    results = response[0].childNodes
    items = None
    
    for result in results:
        if result.nodeName == "result":
            items = result.childNodes
      
    for item in items:
        if item.nodeName == "iros.openapi.service.vo.goodPriceVO":
            info = item.childNodes
            for good in info:
                if good.nodeName == "goodId":
                    print(EntpDic[code], end = '\t')
                    print(GoodsDic[good.firstChild.nodeValue], end = '\t')
                if good.nodeName == "goodPrice":
                    print("가격 : ",good.firstChild.nodeValue,"원", end = '\t')
                if good.nodeName == "plusoneYn":
                    print("원플러스원 : ",good.firstChild.nodeValue, end = '\t')
                if good.nodeName == "goodDcYn":
                    print("할인 : ",good.firstChild.nodeValue)
                    
def GoodsSearch():
    Doc = None
    url = None
    XML = None
    if not checkDoc():
        return None
    
    code = input("상품 코드를 입력하세요 : ")

    url = "http://"+server+"/openApiImpl/ProductPriceInfoService/getProductPriceInfoSvc.do?goodInspectDay=20160610&goodId="+code+"&ServiceKey="+key
    
    try:
        XML = urlopen(url)
        
    except IOError:
        print ("error : 서버접속에 실패했습니다 !")
        return False
        
    else:
        Doc = parse(XML)
           
    response = Doc.childNodes
    results = response[0].childNodes
    items = None
    
    for result in results:
        if result.nodeName == "result":
            items = result.childNodes
      
    for item in items:
        if item.nodeName == "iros.openapi.service.vo.goodPriceVO":
            info = item.childNodes
            for good in info:
                if good.nodeName == "entpId":
                    print(GoodsDic[code], end = '\t')
                    print(EntpDic[good.firstChild.nodeValue], end = '\t')
                if good.nodeName == "goodPrice":
                    print("가격 : ",good.firstChild.nodeValue,"원", end = '\t')
                if good.nodeName == "plusoneYn":
                    print("원플러스원 : ",good.firstChild.nodeValue, end = '\t')
                if good.nodeName == "goodDcYn":
                    print("할인 : ",good.firstChild.nodeValue)
                    
def LoadXMLFromWeb():
    global GoodsDoc, EntpDoc
    global server, key, address
    

    good_url = "http://"+server+"/openApiImpl/ProductPriceInfoService/getProductInfoSvc.do?ServiceKey="+key
    entp_url = "http://"+server+"/openApiImpl/ProductPriceInfoService/getStoreInfoSvc.do?ServiceKey="+key
    
    try:
        goodXML = urlopen(good_url)
        entpXML = urlopen(entp_url)
        
    except IOError:
        print ("error : 서버접속에 실패했습니다 !")
        return False
        
    else:
        try:
            GoodsDoc = parse(goodXML)
            EntpDoc = parse(entpXML)
                 
        except Exception:
            print ("error : 로드에 실패했습니다 !")
        else:
            MakeDic()
            print ("로드에 성공했습니다 !")
            return True
    return False
    
def MakeDic():
    global GoodsDic, EntpDic
    global GoodsList, EntpList
    
    response = GoodsDoc.childNodes
    results = response[0].childNodes
    items = None
    
    for result in results:
        if result.nodeName == "result":
            items = result.childNodes
    
    for item in items:
        id = None
        if item.nodeName == "item":
            info = item.childNodes
            for good in info:
                if good.nodeName == "goodId":
                    id = good.firstChild.nodeValue
                if good.nodeName == "goodName":
                    GoodsDic[id] = good.firstChild.nodeValue
                    
    # 리스트 만들기                
    try:
        tree = ElementTree.fromstring(str(GoodsDoc.toxml()))
    except Exception:
        print ("Element Tree parsing Error : maybe the xml document is not corrected.")
        return None
            

    goodElements = tree.getiterator("item") 
    for item in goodElements:
        strTitle = item.find("goodName")
        GoodsList.append(strTitle.text)

    # 업체 파싱
    response = EntpDoc.childNodes
    results = response[0].childNodes
    items = None
    

    for result in results:
        if result.nodeName == "result":
            items = result.childNodes
                
    for item in items:
        id = None
        if item.nodeName == "iros.openapi.service.vo.entpInfoVO":
            info = item.childNodes
            for good in info:
                if good.nodeName == "entpId":
                    id = good.firstChild.nodeValue
                if good.nodeName == "entpName":
                    EntpDic[id] = good.firstChild.nodeValue    
                    
      # 리스트 만들기  
    try:
        tree = ElementTree.fromstring(str(EntpDoc.toxml()))
    except Exception:
        print ("Element Tree parsing Error : maybe the xml document is not corrected.")
        return None
            

    goodElements = tree.getiterator("iros.openapi.service.vo.entpInfoVO") 
    for item in goodElements:
        strTitle = item.find("entpId")
        EntpList.append(EntpDic[strTitle.text])

     
def PrintGoods():
    for k,v in GoodsDic.items():
        print (k,v)
        
def PrintEntp():
    for k,v in EntpDic.items():
        print (k,v)
        
def SortGood():
    global SortDic    
    
    Doc = None
    url = None
    XML = None
    if not checkDoc():
        return None
    
    code = input("상품 코드를 입력하세요 : ")

    url = "http://"+server+"/openApiImpl/ProductPriceInfoService/getProductPriceInfoSvc.do?goodInspectDay=20160610&goodId="+code+"&ServiceKey="+key
    
    try:
        XML = urlopen(url)
        
    except IOError:
        print ("error : 서버접속에 실패했습니다 !")
        return False
        
    else:
        Doc = parse(XML)
           
    response = Doc.childNodes
    results = response[0].childNodes
    items = None
    
    for result in results:
        if result.nodeName == "result":
            items = result.childNodes
      
    for item in items:
        id = None
        if item.nodeName == "iros.openapi.service.vo.goodPriceVO":
            info = item.childNodes
            for good in info:
                if good.nodeName == "entpId":
                    id = good.firstChild.nodeValue
                if good.nodeName == "goodPrice":
                    SortDic[EntpDic[id]] = good.firstChild.nodeValue
    
    # print(sorted(SortDic, key=lambda k : SortDic[k]))
    try:
        print(GoodsDic[code],"을 검색합니다")
        
    except Exception:
        print("해당 상품이 없습니다")
        
    else:
         list = sorted(SortDic.items(), key=lambda t : t[1])
         i = 0
         for k,v in list:
             if i <10:
                 print(i+1,'.\t',k,'\t',v,'원')
             i+=1
             
def CompEntp():
    if not checkDoc():
        return None
        
    first_url = None
    second_url = None
    
    first_XML = None
    second_XML = None
    
    first_Doc = None
    second_Doc = None
    
    first_list = []
    second_list = []
    
    print("비교할 두 업체의 코드를 입력하세요")
    first_code = input("첫번째 업체의 코드를 입력하세요 : ")
    second_code = input("두번째 업체의 코드를 입력하세요 : ")
    
    first_url = "http://"+server+"/openApiImpl/ProductPriceInfoService/getProductPriceInfoSvc.do?goodInspectDay=20160610&entpId="+first_code+"&ServiceKey="+key
    second_url = "http://"+server+"/openApiImpl/ProductPriceInfoService/getProductPriceInfoSvc.do?goodInspectDay=20160610&entpId="+second_code+"&ServiceKey="+key
    
    try:
        first_XML = urlopen(first_url)
        second_XML = urlopen(second_url)
        
    except IOError:
        print ("error : 서버접속에 실패했습니다 !")
        return False
        
    else:
        first_Doc = parse(first_XML)
        second_Doc = parse(second_XML)
    

    # 첫번째 업체
    response = first_Doc.childNodes
    results = response[0].childNodes
    items = None
    
    for result in results:
        if result.nodeName == "result":
            items = result.childNodes
      
    for item in items:
        if item.nodeName == "iros.openapi.service.vo.goodPriceVO":
            info = item.childNodes
            for good in info:
                if good.nodeName == "goodId":
                    first_list.append(good.firstChild.nodeValue)
                    
    # 두번째 업체
    response = second_Doc.childNodes
    results = response[0].childNodes
    items = None
    
    for result in results:
        if result.nodeName == "result":
            items = result.childNodes
      
    for item in items:
        if item.nodeName == "iros.openapi.service.vo.goodPriceVO":
            info = item.childNodes
            for good in info:
                if good.nodeName == "goodId":
                    second_list.append(good.firstChild.nodeValue)
                    
    print("\n공통된 상품을 출력합니다\n")
    for i in first_list:
        for j in second_list:
            if i==j:
                print (i, GoodsDic[i])
    print("\n----------------------------------------")          
    print("자세한 비교를 원하면 대상 코드를 입력하세요")
    print("   -메뉴로 돌아가려면 'q'를 입력합니다-")
    print("----------------------------------------")
    cmd = input()
    
    if cmd == 'q':
        return 0
    else:
        
    # 첫번째
        response = first_Doc.childNodes
        results = response[0].childNodes
        items = None
    
        for result in results:
            if result.nodeName == "result":
                items = result.childNodes
    
        print('',EntpDic[first_code], end = '\t')
        for item in items:
            if item.nodeName == "iros.openapi.service.vo.goodPriceVO":
                info = item.childNodes
                for good in info:
                    if good.nodeName == "goodId":
                        if good.firstChild.nodeValue != cmd:
                            break
                    if good.nodeName == "goodId":
                        print(GoodsDic[good.firstChild.nodeValue], end = '\t')
                    if good.nodeName == "goodPrice":
                        print("가격 : ",good.firstChild.nodeValue,"원", end = '\t')
                    if good.nodeName == "plusoneYn":
                        print("원플러스원 : ",good.firstChild.nodeValue, end = '\t')
                    if good.nodeName == "goodDcYn":
                        print("할인 : ",good.firstChild.nodeValue)
                                         
    # 두번째
        response = second_Doc.childNodes
        results = response[0].childNodes
        items = None
    
        for result in results:
            if result.nodeName == "result":
                items = result.childNodes
    
        print('\n',EntpDic[second_code], end = '\t')
        for item in items:
            if item.nodeName == "iros.openapi.service.vo.goodPriceVO":
                info = item.childNodes
                for good in info:
                    if good.nodeName == "goodId":
                        if good.firstChild.nodeValue != cmd:
                            break
                    if good.nodeName == "goodId":
                        print(GoodsDic[good.firstChild.nodeValue], end = '\t')
                    if good.nodeName == "goodPrice":
                        print("가격 : ",good.firstChild.nodeValue,"원", end = '\t')
                    if good.nodeName == "plusoneYn":
                        print("원플러스원 : ",good.firstChild.nodeValue, end = '\t')
                    if good.nodeName == "goodDcYn":
                        print("할인 : ",good.firstChild.nodeValue)
        